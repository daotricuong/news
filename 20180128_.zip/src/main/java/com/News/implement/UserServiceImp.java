package com.News.implement;

import com.News.DAO.UserDaoImp;
import com.News.Entity.User;
import com.News.Service.UserService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import java.util.List;



@Service
public class UserServiceImp implements UserService {

    @Override
    public List<User> getAllUser() {
        return null;
    }

    @Override
    public boolean create(User user, String id) {

    }

    @Override
    public User getUser(String id) {
        return null;
    }

    @Override
    public List<User> listuser() {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        UserDaoImp daoImp = (UserDaoImp) context.getBean("userDao");
        List<User> user =  daoImp.listUser();
        return user;
    }

    @Override
    public boolean delete(String id) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        UserDaoImp daoImp = (UserDaoImp) context.getBean("topicDAO");
        try{
            return daoImp.delete(id);
        } catch (Exception e){
            return false;
        }
    }

    @Override
    public boolean update(User user, String id) {

    }
}
