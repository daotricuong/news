package com.News.DAO;

import com.News.Entity.Topic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Test {

    public static void main(String[] args) {
//        Topic topic = new Topic();
//        List<String> list = new ArrayList<String>();
//        list.add("aa");
//        list.add(null);
//        topic.setTag(list);
//        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
//        Date date = new Date();
//        System.out.println(date.toString());
//        System.out.println(topic.getTagStr());
//        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//        CatalogueDaoImp catalogueDaoImp = (CatalogueDaoImp) context.getBean("catalogueDAO");
//        System.out.println(catalogueDaoImp.getCatalogue("thethao").toString());
////        System.out.println(catalogueDaoImp.getCatalogueTopic("thethao").toString());
        System.out.println(4%5);
        for (int i =0;i<1;i++){
            System.out.println(i);
        }

    }
}
