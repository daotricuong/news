$(document).ready(function() {
        $('#table').dataTable();
} );