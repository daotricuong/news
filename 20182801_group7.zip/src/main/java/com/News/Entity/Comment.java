package com.News.Entity;

public class Comment {
    private int topicId;
    private String cmtName;
    private String cmtBody;
    private String cmtCover;
    private String cmtStatus;
    private String cmtLike;
    private String cmtLikeCount;
    private String cmtDisLikeCount;
}
