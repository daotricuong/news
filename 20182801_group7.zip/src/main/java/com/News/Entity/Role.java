package com.News.Entity;

public class Role {
    private String roleId;
    private String roleName;
}
