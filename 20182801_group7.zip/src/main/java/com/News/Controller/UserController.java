package com.News.Controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
@RequestMapping("/page")
public class UserController{

    @RequestMapping(value = "cuong" , method = RequestMethod.GET)
    public String test(ModelMap model) {
        model.put("hello", "a");
        return "test";
    }



    public String infor(ModelMap modelMap){

    return "com/";
    }

}
